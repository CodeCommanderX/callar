const express = require('express');
const app = express();
const server = require('http').createServer(app);
const path = require("path");
const SkyRTC = require('./public/dist/js/SkyRTC.js').listen(server);
const port = process.env.PORT || 3000;
const hostname = "0.0.0.0";

app.use(express.static(path.join(__dirname, 'public')), null);

server.listen(port, hostname, function () {
    console.log(`Server đang chạy tại http://${hostname}:${port}/`);
});

app.get('/', function (req, res) {
    res.sendfile(__dirname + '/index.html');
});

SkyRTC.rtc.on('new_connect', function (socket) {
    console.log('Tạo kết nối mới');
});

SkyRTC.rtc.on('remove_peer', function (socketId) {
    console.log(socketId + " người dùng rời khỏi");
});

SkyRTC.rtc.on('new_peer', function (socket, room) {
    console.log("Người dùng mới " + socket.id + " tham gia phòng " + room);
});

SkyRTC.rtc.on('socket_message', function (socket, msg) {
    console.log("Nhận được tin nhắn mới từ " + socket.id + ": " + msg);
});

SkyRTC.rtc.on('ice_candidate', function (socket, ice_candidate) {
    console.log("Nhận được ICE Candidate từ " + socket.id);
});

SkyRTC.rtc.on('offer', function (socket, offer) {
    console.log("Nhận được Offer từ " + socket.id);
});

SkyRTC.rtc.on('answer', function (socket, answer) {
    console.log("Nhận được Answer từ " + socket.id);
});

SkyRTC.rtc.on('error', function (error) {
    console.log("Đã xảy ra lỗi: " + error.message);
});
